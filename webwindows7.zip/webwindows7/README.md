# WebWindows 7

Simulación web de un ordenador con Windows 7 (estilo Aero), hecha solo con HTML, CSS y JavaScript. **Es una simulación**: no es Windows, no ejecuta programas reales y no toca tu ordenador.

## Cómo ejecutarlo
Abre `index.html` en el navegador. Sin servidor, sin dependencias. La contraseña inicial está vacía: pulsa "Log on".

## Qué es virtual
- **RAM**: 8192 MB simulados por `ProcessManager` (`PM`). Cada ventana abierta reserva RAM; al cerrarla se libera. Si no cabe, se muestra "Your computer is low on memory".
- **CPU**: Intel Core i5-2500 ficticio. El uso por proceso fluctúa cada segundo.
- **Disco C:** 500 GB virtuales (`FS`): un árbol de objetos JS guardado en `localStorage`. No se crea ningún archivo grande. La Papelera sigue ocupando espacio hasta vaciarla.
- **Persistencia**: archivos, carpetas, apps instaladas, fondo, usuario, contraseña e historial sobreviven a recargar la página.

## Arquitectura (`script.js`)
`FS` (almacenamiento), `PM` (procesos), `WM` (ventanas), `APPS`/`launch`/`installer`/`unins` (aplicaciones), y el objeto `VirtualOS` expuesto en las DevTools para depuración. El estado del sistema es `BOOTING`, `LOGIN`, `RUNNING`, `LOCKED`, `SHUTTING_DOWN` o `RESTARTING`.

## Aplicaciones incluidas
Windows Explorer (con Papelera), Notepad, Calculator (estándar), Paint, Command Prompt, Internet Explorer, Control Panel (programas, personalización, cuenta, sistema), Task Manager (Applications, Processes, Performance) y WebSoft Store (descarga e instalación simuladas).

## Seguridad y límites
- Nada se ejecuta fuera de la simulación; `cmd` solo opera sobre el sistema de archivos virtual.
- Internet Explorer no tiene conexión propia: las búsquedas se abren en una pestaña real de tu navegador.
- No incluidas todavía: copiar/pegar en el Explorer, calculadora científica, gadgets, registro, Windows Update, sonidos, pantalla azul, resolución virtual, pantalla completa, calendario y pestañas del navegador.
